from vocab import Vocabulary
from hmm import HMM
import numpy as np

def get_manning_schutze_cola_hmm():
    s = Vocabulary('S')
    cp = s.int("cola preference")
    ip = s.int("iced tea preference")

    k = Vocabulary('K')
    cola = k.int("cola")
    ice_t = k.int("iced tea")
    lem = k.int("lemonade")

    # a is an N x N matrix, where N is the number of states
    a = np.matrix([[0.7, 0.3],  # Probability of transiting from cola state to other states
                   [0.5, 0.5]])  # Probability of transiting from iced tea state to other states

    # b is an N x M matrix, where M is the output vocabulary size
    b = np.matrix([[0.6, 0.1, 0.3],  # Probability of emitting various symbols from cola state
                   [0.1, 0.7, 0.2]])  # Probability of emitting various symbols from iced tea state

    # pi is a 1 x N matrix
    pi = np.matrix([[1.0, 0.0]])  # Probability of starting in each state

    o = [lem, ice_t, cola]
    hmm = HMM(o, s, k, a, b, pi)

    return hmm

