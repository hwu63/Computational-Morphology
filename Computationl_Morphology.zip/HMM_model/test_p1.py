from cola import get_manning_schutze_cola_hmm
import numpy as np
import unittest

class TestHW06(unittest.TestCase):

    manning_schutze_cola_hmm = get_manning_schutze_cola_hmm()

    def test_forward(self):

        alpha = TestHW06.manning_schutze_cola_hmm.forward()

        expected_alpha = np.matrix([[1.0, 0.0],
                                    [0.21, 0.09],
                                    [0.0462, 0.0378],
                                    [0.021294, 0.010206]])

        np.testing.assert_allclose(alpha, expected_alpha)

    def test_backward(self):

        beta = TestHW06.manning_schutze_cola_hmm.backward()

        expected_beta = np.matrix([[0.0315, 0.029],
                                   [0.045, 0.245],
                                   [0.6, 0.1],
                                   [1.0, 1.0]])

        np.testing.assert_allclose(beta, expected_beta)

    def test_probability_of_observation_sequence(self):

        alpha = TestHW06.manning_schutze_cola_hmm.forward()
        beta = TestHW06.manning_schutze_cola_hmm.backward()

        for t in range(0,4):
            np.testing.assert_almost_equal(alpha[t, 0]*beta[t, 0] + alpha[t, 1]*beta[t, 1], 0.0315)

    def test_gamma(self):

        gamma = TestHW06.manning_schutze_cola_hmm.state_probabilities()

        expected_gamma = np.matrix([[1.0, 0.0],
                                    [0.3, 0.7],
                                    [0.88, 0.12],
                                    [0.676, 0.324]])

        np.testing.assert_allclose(gamma, expected_gamma)



if __name__ == '__main__':
    unittest.main()
