import numpy

class HMM:

    def __init__(self, o, s, k, a, b, pi):
      self.o = o
      self.s = s
      self.k = k 
      self.a = a 
      self.b = b 
      self.pi = pi
      
      self.n = len(self.a)
      self.m = len(self.b[0])
    

    # Required for HW06
    def forward(self):
        """Returns the forward trellis (alpha) for this HMM"""
        self.alpha = numpy.zeros((len(self.o)+1, self.n))
        
        for i in range(self.n):
            self.alpha[0, i] = self.pi[0, i]
        
        for t in range(1, len(self.o)+1 ):
            for j in range(self.n):
                for i in range(self.n):
                    self.alpha[t, j] += self.alpha[t-1, i] * self.a[i, j] * self.b[i, self.o[t-1]]
            
        return self.alpha

    # Required for HW06
    def backward(self):
        """Returns the backward trellis (beta) for this HMM"""
        self.beta = numpy.zeros((len(self.o)+1, self.n))
        self.beta[len(self.o)] = numpy.ones((self.n))
        
        # induction
        for t in range(len(self.o)-1,-1,-1):
            for i in range(self.n):
                for j in range(self.n):
                    self.beta[t, i] += self.a[i, j] * self.b[i, self.o[t]] * self.beta[t+1, j]

        return self.beta

    # Required for HW06
    def state_probabilities(self):
        """Returns the state probabilities (gamma) for this HMM"""
        alpha = self.forward()
        beta = self.backward()
        
        self.gamma = numpy.zeros((len(self.o)+1, self.n))
        
        for i in range(len(self.gamma)):
            prob_sum = 0
            for s in range(self.n):
                prob = alpha[i, s] * beta[i, s]
                self.gamma[i, s] = prob
                prob_sum += prob

            if prob_sum == 0:
                continue

            for s in range(self.n):
                self.gamma[i, s] /= prob_sum
        
        return self.gamma


    # Required for HW07
    def best_individual_states(self):
        """Returns the sequence of states such that at each time, the state with the highest probability at that time step is chosen"""
        return self.state_probabilities().argmax(axis=1).tolist()
            

    # Required for HW07
    def viterbi(self):
        """Returns the sequence of states selected by the Viterbi algorithm"""
        self.delta = numpy.zeros((len(self.o)+1, self.n))
        self.delta[0] =numpy.matrix([1, 0]) 
        self.psi = numpy.zeros((len(self.o)+1, self.n))
        for i in range(self.n):
          self.psi[0][i] = -1 
        
        for t in range(len(self.o)):
          m = self.o[t] 	
          for j in range(self.n):
            for i in range(self.n):
              previous_prob = self.delta[t, i]
              transmission_prob = self.a[i, j]
              emission_prob = self.b[i, m]
              prob_term =	previous_prob * transmission_prob * emission_prob
              
              if prob_term >= self.delta[t+1, j]:
                self.delta[t+1, j] = prob_term
                self.psi[t+1, j] = i
                
        most_probable_sequence = [0] + self.psi[1:, 0].tolist()
        most_probable_sequence = list(map(int, most_probable_sequence))
        most_probable_sequence.reverse()
        sequence_probability = self.delta[-1, most_probable_sequence[0]]
        

        
        return self.delta, self.psi, most_probable_sequence, sequence_probability

     
