from cola import get_manning_schutze_cola_hmm
import numpy as np
from test_HW06 import TestHW06
import unittest

class TestHW07(unittest.TestCase):

    manning_schutze_cola_hmm = get_manning_schutze_cola_hmm()

    def test_max_individual_states(self):

        sequence = TestHW07.manning_schutze_cola_hmm.best_individual_states()

        expected_sequence = [0, 1, 0, 0]

        self.assertEqual(sequence, expected_sequence)

    def test_viterbi(self):

        delta, psi, most_probable_sequence, sequence_probability = TestHW07.manning_schutze_cola_hmm.viterbi()

        expected_delta = np.matrix([[1.0, 0.0],
                                    [0.21, 0.09],
                                    [0.0315, 0.0315],
                                    [0.01323, 0.00567]])

        expected_psi = np.matrix([[-1, -1],
                                  [0, 0],
                                  [1, 1],
                                  [0, 0]])

        expected_best_sequence = [0, 1, 0, 0]

        expected_sequence_probability = 0.01323

        np.testing.assert_allclose(delta, expected_delta)
        np.testing.assert_allclose(psi, expected_psi)
        np.testing.assert_allclose(most_probable_sequence, expected_best_sequence)
        np.testing.assert_almost_equal(sequence_probability, expected_sequence_probability)


if __name__ == '__main__':
    unittest.main()
