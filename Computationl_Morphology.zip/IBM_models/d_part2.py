#!/usr/bin/python3

import sys
import nltk

from itertools import product
from collections import OrderedDict
# Import d_part1.py
from d_part1 import Vocabulary

# PART D2
#
# Complete the body of this class 
#   by implementing the unimplemented methods

class Conditional:

    # Define a constructor
    #
    # For every pair of words (one from e, one from f),
    #    store the value provided by initial_value
    # 
    # HINT: In addition to storing the name and both vocabs,
    #       you will need to store a dictionary of dictionaries
    def __init__(self, name, e_vocab, f_vocab, initial_value):
        self.dict = OrderedDict()
        self.name = name
        self.e_vocab = e_vocab
        self.f_vocab = f_vocab

        for e, f in product(e_vocab.word2int, f_vocab.word2int):
            self.dict[(e, f)] = initial_value

    # Given an integer index for a word from e and a word from f,
    #    return the corresponding value
    def get(self, e_i, f_i):
        #print(self.e_vocab, self.f_vocab)
        if self.e_vocab.get_word(e_i) and self.f_vocab.get_word(f_i):
            return self.dict[(self.e_vocab.get_word(e_i), self.f_vocab.get_word(f_i))]
        else:
            return 0.0

    # Given an integer index for a word from e and a word from f,
    #    store the value provided
    def set(self, e_i, f_i, value):
        if(value > 0.0):
            self.dict[(self.e_vocab.get_word(e_i), self.f_vocab.get_word(f_i))] = value


    # Return a string representation of this object
    #
    # See c.expected_output and test_c.py for the format of the string
    def __str__(self):
        ret = ''
        for key, val  in self.dict.items():
            ret += "{}[{} | {}] = {}\n".format(self.name, key[0], key[1], val)
        return ret



def create_vocab(words):
    v = Vocabulary()
    for word in words:
        v.get_int(word)
    return v


if __name__ == '__main__':

    if (len(sys.argv) > 2):
        f1 = open(sys.argv[1])
        raw1 = f1.read()
        words_e=nltk.word_tokenize(raw1)

        f2 = open(sys.argv[2])
        raw2 = f2.read()
        words_f=nltk.word_tokenize(raw2)

    else:
        words_e = nltk.word_tokenize("All human beings are born free and equal in dignity and rights. They are endowed with reason and conscience and should act towards one another in a spirit of brotherhood.")
        
        words_f = nltk.word_tokenize("Todos los seres humanos nacen libres e iguales en dignidad y derechos y, dotados como están de razón y conciencia, deben comportarse fraternalmente los unos con los otros.")

        e_v = create_vocab(words_e)
        f_v = create_vocab(words_f)
        
        count = Conditional("count", e_v, f_v, 0)
        print(count)
        print()
