#!/usr/bin/python3

# tests for min_edit_distance.py
import unittest

from matrix import Matrix
from min_edit_distance import *

class TestMinEditDistanceCalculator(unittest.TestCase):

    def setUp(self):
        self.calculator = Min_Edit_Distance_Calculator("kitten", "sitting")
        self.distances = Matrix(7,8)

    def test_construtor(self):
        self.assertEqual(self.calculator.source, "kitten")
        self.assertEqual(self.calculator.target, "sitting")

        
    def test_initialize_distance_matrix(self):
        self.calculator.initialize_distance_matrix(self.distances)
        for i in range(0,7):
            self.assertEqual(self.distances[i][0], i)
        for j in range(0,8):
            self.assertEqual(self.distances[0][j], j)
        
    def test_calculate_recurrence(self):
        self.calculator.initialize_distance_matrix(self.distances)
        self.calculator.calculate_recurrence(self.distances)
        for i in range(0,7):
            for j in range(0,8):
                    self.assertGreaterEqual(self.distances[i][j], 0)
        self.assertEqual(self.distances[6][7], 5)
        
class TestMinEditDistance(unittest.TestCase):

    def test_empty_string(self):
        self.assertEqual(min_edit_distance("", ""), 0)
        self.assertEqual(min_edit_distance("", "ab"), 2)
        self.assertEqual(min_edit_distance("abc", ""), 3)
        
    def test_identical(self):
        self.assertEqual(min_edit_distance("ab", "ab"), 0)
        
    def test_substring(self):
        self.assertEqual(min_edit_distance("ab", "abc"), 1)
        self.assertEqual(min_edit_distance("cranberry", "err"), 6)
        
    def test_upperbound(self):
        self.assertEqual(min_edit_distance("asdf", "qwerty"), 10)
        
    def test_commutativity(self):
        self.assertEqual(min_edit_distance("asdf", "qwerty"), min_edit_distance("qwerty", "asdf"))
        
if __name__ == '__main__':
    unittest.main()
