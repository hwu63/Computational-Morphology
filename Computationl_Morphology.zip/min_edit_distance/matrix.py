#!/usr/bin/python3

# class Matrix
# for the minimum edit distance algorithm, Chapter 2.4, Jurafsky & Martin SLP3

import numpy as np

class Matrix:

    
    def __init__(self, nrow, ncol, default=None):
        self.row = nrow
        self.col = ncol
        self.matrix = np.full((nrow, ncol), default)

        #num of row in matrix
    def nrow(self):
        return self.row

    def ncol(self):
        return self.col

    #return the row corresponding to index
    def __getitem__(self, index):
        return self.matrix[index]

    def __str__(self):
        return '\n'.join('\t'.join(map(str, row)) for row in self.matrix)

# main function
if __name__ == '__main__':

    distances = Matrix(4,5)
    print(distances)
    distances[0][0] = 0
    print(distances[0][0])
