#!/usr/bin/python3

# unit test for levenshtein functions
import unittest
from levenshtein import *

class TestLevenshtein(unittest.TestCase):

    def test_ins_cost(self):
        self.assertEqual(ins_cost("c"), 1)
        self.assertEqual(ins_cost("ab"), 1)
        self.assertEqual(ins_cost("c"),ins_cost("ab"))

    def test_del_cost(self):
        self.assertEqual(del_cost("c"), 1)
        self.assertEqual(del_cost("ab"), 1)
        self.assertEqual(del_cost("c"), ins_cost("ab"))

    def test_sub_cost(self):
        self.assertEqual(sub_cost("c", "c"), 0)
        self.assertEqual(sub_cost("a", "b"), 2)

if __name__ == '__main__':
    unittest.main()
