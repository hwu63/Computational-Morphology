#!/usr/bin/python3

# Levenshtein distances in Eq. 2.2, for the minimum edit distance algorithm, Chapter 2.4, Jurafsky & Martin SLP3

def del_cost(source):
    if source == None:
        return 0
    elif isinstance(source, str):
        return 1
    else:
        return len(source)
      
    
def ins_cost(source):
    if source == None:
        return 0
    elif isinstance(source, str):
        return 1
    else:
        return len(source)
    
def sub_cost(source, target):
    if source == target:
        return 0
    else:
        return 2
