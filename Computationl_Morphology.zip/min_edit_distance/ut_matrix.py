#!/usr/bin/python3

# unit test for the Matrix class
import unittest
from matrix import Matrix

class TestMatrix(unittest.TestCase):

    def test_construtor(self):
        matrix = Matrix(4,5)
        self.assertEqual(matrix.nrow(), 4)
        self.assertEqual(matrix.ncol(), 5)
        for i in range(0,4):
            for j in range(0,5):
                self.assertEqual(matrix[i][j], None)
        
    def test_construtor_with_default(self):
        matrix = Matrix(2,6,2.7)
        self.assertEqual(matrix.nrow(), 2)
        self.assertEqual(matrix.ncol(), 6)
        for i in range(0,2):
            for j in range(0,6):
                self.assertEqual(matrix[i][j], 2.7)
        
    def test_set_get(self):
        matrix = Matrix(2,6,2.7)
        self.assertEqual(matrix[0][5], 2.7)
        matrix[0][5] = 2.5
        for i in range(0,2):
            for j in range(0,6):
                if i == 0 and j == 5:
                    self.assertEqual(matrix[i][j], 2.5)
                else:
                    self.assertEqual(matrix[i][j], 2.7)

    def test_string(self):
        matrix = Matrix(2,4,2.7)
        self.assertEqual(str(matrix), "\n2.7\t2.7\t2.7\t2.7\n2.7\t2.7\t2.7\t2.7\n")

if __name__ == '__main__':
    unittest.main()
