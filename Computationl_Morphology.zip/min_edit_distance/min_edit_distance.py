#!/usr/bin/python3

# minimum edit distance class
# from Fig 2.15, Chapter 2.4, Jurafsky & Martin SLP3

from levenshtein import *
from matrix import Matrix

class Min_Edit_Distance_Calculator:

      def __init__(self, source, target):
      self.source = source
      self.target = target
      self.n = len(source)
      self.m = len(target)
      self.distances = Matrix(self.n+1, self.m+1)




# # Initialization: the zeroth row and column is the distance from the empty string
# D[0,0] = 0
# for each row i from 1 to n do
# D[i,0]←D[i-1,0] + del-cost(source[i])
# for each column j from 1 to m do
# D[0,j]←D[0, j-1] + ins-cost(target[j])

    # initialize distance matrix: zero-th row and column
    def initialize_distance_matrix(self, distances):
      distances[0][0] = 0
      for i in range(1,self.n+1):
        distances[i][0]= distances[i-1][0] + del_cost(self.source[i-1])
      for j in range(1,self.m+1):
        distances[0][j] = distances[0][j-1] + ins_cost(self.source[j-1])



# # Recurrence relation:
# for each row i from 1 to n do
# for each column j from 1 to m do
# D[i, j]←MIN( D[i−1, j] + del-cost(source[i]),
# D[i−1, j−1] + sub-cost(source[i], target[j]),
# D[i, j−1] + ins-cost(target[j]))
# # Termination
# return D[n,m]

    # calculate recurrence
    def calculate_recurrence(self, distances):
        for i in range(1,self.n+1):
          for j in range(1,self.m+1):
            distances[i][j] = min(distances[i-1][j] + del_cost(self.source[i-1]),
              distances[i-1][j-1] + sub_cost(self.source[i-1], self.target[j-1]),
              distances[i][j-1] + ins_cost(self.target[j-1]))
        return distances[self.n][self.m]

# minimum edit distance algorithm
def min_edit_distance(source, target):
    mat = Min_Edit_Distance_Calculator(source, target)
    mat.initialize_distance_matrix(mat.distances)
    return mat.calculate_recurrence(mat.distances)


# main function
if __name__ == '__main__':

    print(min_edit_distance("kitten", "sitting"))
    
    
    
