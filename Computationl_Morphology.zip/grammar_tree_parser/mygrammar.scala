trait Symbol {
  
  val value : String
  
  override def toString(): String = {
    return value
  } 
  
  def isEpsilon(): Boolean
  
}

object epsilon extends Symbol {
  val value : String = "ε"
  
  def isEpsilon(): Boolean = {
    return true
  }
}



class Terminal(val value: String) extends Symbol {
  
  def isEpsilon(): Boolean = {
    return false
  }
  
}

class Nonterminal(val value: String) extends Symbol { 
 
  def isEpsilon(): Boolean = {
    return false
  }
}


class Rule(val lhs: Nonterminal, val rhs: Seq[Symbol]) {
  
  override def toString(): String = {
    return s"${lhs} → ${rhs.mkString(" ")}"
  }
  
}

object Grammar {
  
  def readRules(fileName: String) : Iterator[Rule] = {
    import scala.io.Source
    
    val lines = Source.fromFile(fileName).getLines()
  
    val result = lines.map({ line:String => readRule(line)})
    
    return result
  }
  
  def readRule(line: String) : Rule = {
    
    val parts = line.split("\\s+").toList
    
    val lhsString = parts(0)
    val rhsStrings: List[String] = parts.slice(1, parts.size)
    
    val lhs = new Nonterminal(lhsString)
    
    val rhs:Seq[Symbol] = 
      
      if (rhsStrings.isEmpty) {
    
        Seq(Epsilon)
        
      } else {

        rhsStrings.map{ rhsString:String =>  
      
          if (rhsString.charAt(0).isUpper) {
            new Nonterminal(rhsString)
          } else {
            new Terminal(rhsString)
          }
        
      }
      
    }
    
    return new Rule(lhs, rhs)
    
  }
  
}

object MyProgram {
  def main(args: Array[String]): Unit = {
  
    epsilon.isEpsilon()
    
    if (args.length == 0) {
      
      println("User must provide a text file as an argument")
      
    } else {
      
      val fileName = args(0)
      
      for (rule <- Grammar.readRules(fileName)) {
        println(rule)
      }
      
    }

  
  }
}
