import sys

from mygrammar import *

class Cell:

    def __init__(self, value, left_child, right_child=None):
        """Initializes a CKY parse chart cell, storing a value (that corresponds to the left-hand side of a context-free rule, 
        a left-child (that corresponds to the first symbol on the right-hand side of the context-free rule), 
        and a right-child (that is None if the rule is unary, or if the rule is binary corresponds to the second symbol 
        on the right-hand side of the context-free rule)."""
        
        self.value = value
        self.left_child = left_child
        self.right_child = right_child

    def __str__(self):
        if self.right_child==None:
            return "(" + str(self.value) + " " + str(self.left_child) + ")"
        else:
            return "(" + str(self.value) + " " + str(self.left_child) + " " + str(self.right_child) + ")"

    def __repr__(self):
        if self.right_child==None:
            return "Cell(" + str(self.value) + ", " + str(self.left_child) + ")"
        else:
            return "Cell(" + str(self.value) + ", " + str(self.left_child) + ", " + str(self.right_child) + ")"


# The use of this function is optional, but strongly recommended
#
def num_cells(length):
    """Given length (the number of words in the sentence), returns the number of cells in the corresponding parse chart"""
    ret = 0
    for i in range(length+1):
        ret += i
    return ret

# The use of this function is optional, but strongly recommended
#
def cell_index(start, end, length):
    """Given length (the number of words in the sentence), as well as a span defined by a start and end index,
    returns an integer in the range [0, num_cell). A call to this function with cell_index(0, length, length) should return zero."""
    line_no = length - (end - start)
    return num_cells(line_no) + start

# The use of this class is optional, but strongly recommended
#
class Chart:

    def __init__(self, n):
        """Initializes a CKY parse chart for a sentence of length n"""
        self.length = n
        self.cells = []
        for i in range(num_cells(n)):
            self.cells.append([])

    def get(self, start, end):
        """Returns a (possibly empty) list of Cell objects that span from start to end"""
        return self.cells[cell_index(start, end, self.length)]
            

    def put(self, start, end, cell):
        """Stores a Cell object that spans from start to end"""
        self.cells[cell_index(start, end, self.length)].append(cell)
        
    def __str__(self):
        ret = ''
        for cell in self.cells:
          ret += cell.__str__() + '\n'
        return ret


class Parser:

    def __init__(self, grammar):
        self.grammar = grammar

    def parse(self, sentence):
        #put into cell.
        n = len(sentence)
        self.chart = Chart(n)
        for i in range(n):
          for rule in self.grammar.rules:
            if rule.rhs[0]  == Symbol.get(sentence[i]):
              print(rule.lhs)
              self.chart.put(i, i+1, Cell(rule.lhs, Symbol.get(sentence[i]), None))
        print(self.chart)
        
        for span in range(2, n+1):
            # print("span",span)
            for start in range(n-span+1):
                end = start + span
                # print("start,end",start,end)
                for mid in range(start +1, end):
                    # print("mid",mid)
                    left_children = self.chart.get(start, mid)
                    right_children = self.chart.get(mid, end)
                    for left_child in left_children:
                        for right_child in right_children:
                            # print(left_child.value, right_child.value)
                            for rule in self.grammar.rules:
                                if rule.rhs == [left_child.value]:
                                    self.chart.put(start, end, Cell(rule.lhs, left_child, None))
                                elif rule.rhs == [right_child.value]:
                                    self.chart.put(start, end, Cell(rule.lhs, right_child, None))
                                elif rule.rhs == [left_child.value, right_child.value] :
                                    self.chart.put(start, end, Cell(rule.lhs, left_child, right_child))
                            # print(self.chart)
        return self.chart.cells[0][0]
                    




if __name__ == "__main__":
    
        fileName = "test.txt"

        with open(fileName) as grammar_file:

            grammar0 = Grammar.readLines(grammar_file)
            print("ha")
            parser = Parser(grammar0)
            print("ha")
            # for line in sys.stdin:
            line = "the boy walks"
            words = line.strip().split()
            result = parser.parse(words)
            print(result)

#     if len(sys.argv) < 2:

#         print("Please provide a file as argument")

#     else:

#         fileName = sys.argv[1]
#         sentence

#         with open(fileName) as grammar_file:

#             grammar0 = Grammar.readLines(grammar_file)
#             grammar1 = grammar0.removeEpsilons()
#             grammar2 = grammar1.removeUnaryRules()
#             grammar3 = grammar2.shortenLongRules()
#             grammar4 = grammar3.makeTerminalsUnary()
            
#             parser = Parser(grammar4)
            
#             for line in sys.stdin:
#                 words = line.strip().split()
#                 result = parser.parse(words)
#                 print(result)
