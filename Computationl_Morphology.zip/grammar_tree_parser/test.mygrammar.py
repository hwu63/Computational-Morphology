#!/usr/bin/env python3

from mygrammar import *
import unittest

import io

class GrammarTest(unittest.TestCase):

    def test_TrueIsTrue(self):
        self.assertTrue(True)

    def test_NullableSymbols(self):
        lines="""NP DT N
DT
N dog
DT the
"""
        file = io.StringIO(lines)
        grammar = Grammar.readLines(file)
        nullableSymbols = grammar.findNullableSymbols()
        self.assertEqual(len(nullableSymbols), 1)
        self.assertTrue(Symbol.get("DT") in nullableSymbols)

    def test_MoreNullableSymbols(self):
        lines="""NP DT N
DT
N dog
NP DT
DT the
"""
        file = io.StringIO(lines)
        grammar = Grammar.readLines(file)
        nullableSymbols = grammar.findNullableSymbols()
        self.assertEqual(len(nullableSymbols), 2)
        self.assertTrue(Symbol.get("DT") in nullableSymbols)
        self.assertTrue(Symbol.get("NP") in nullableSymbols)
        self.assertFalse(Symbol.get("N") in nullableSymbols)
        self.assertFalse(Symbol.get("dog") in nullableSymbols)
        self.assertFalse(Symbol.get("the") in nullableSymbols)


    def test_GetMoreNullableSymbols(self):
        lines="""NP DT N
DT
N dog
NP DT
DT the
"""
        file = io.StringIO(lines)
        grammar = Grammar.readLines(file)
        nullableSymbols = grammar.findInitiallyNullableSymbols()
        self.assertEqual(len(nullableSymbols), 1)
        self.assertTrue(Symbol.get("DT") in nullableSymbols)
        self.assertFalse(Symbol.get("NP") in nullableSymbols)
        self.assertFalse(Symbol.get("N") in nullableSymbols)
        self.assertFalse(Symbol.get("dog") in nullableSymbols)
        self.assertFalse(Symbol.get("the") in nullableSymbols)

        newlyNullableSymbols = grammar.findMoreNullableSymbols(nullableSymbols)
        self.assertFalse(Symbol.get("DT") in newlyNullableSymbols)
        self.assertTrue(Symbol.get("NP") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("N") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("dog") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("the") in newlyNullableSymbols)


    def test_EvenGetMoreNullableSymbols(self):
        lines="""S NP VP
S NP
S VP
NP DT N
NP N
DT
N dog
NP DT
DT the
VP V
V get
V
"""
        file = io.StringIO(lines)
        grammar = Grammar.readLines(file)
        nullableSymbols = grammar.findInitiallyNullableSymbols()
        self.assertEqual(len(nullableSymbols), 2)
        self.assertTrue(Symbol.get("DT") in nullableSymbols)
        self.assertFalse(Symbol.get("NP") in nullableSymbols)
        self.assertFalse(Symbol.get("N") in nullableSymbols)
        self.assertFalse(Symbol.get("VP") in nullableSymbols)
        self.assertTrue(Symbol.get("V") in nullableSymbols)
        self.assertFalse(Symbol.get("S") in nullableSymbols)
        self.assertFalse(Symbol.get("dog") in nullableSymbols)
        self.assertFalse(Symbol.get("get") in nullableSymbols)
        self.assertFalse(Symbol.get("the") in nullableSymbols)

        newlyNullableSymbols = grammar.findMoreNullableSymbols(nullableSymbols)
        self.assertFalse(Symbol.get("DT") in newlyNullableSymbols)
        self.assertTrue(Symbol.get("NP") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("N") in newlyNullableSymbols)
        self.assertTrue(Symbol.get("VP") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("V") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("S") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("dog") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("get") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("the") in newlyNullableSymbols)

        nullableSymbols.update(newlyNullableSymbols)
        newlyNullableSymbols = grammar.findMoreNullableSymbols(nullableSymbols)
        self.assertFalse(Symbol.get("DT") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("NP") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("N") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("VP") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("V") in newlyNullableSymbols)
        self.assertTrue(Symbol.get("S") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("dog") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("get") in newlyNullableSymbols)
        self.assertFalse(Symbol.get("the") in newlyNullableSymbols)

        nullableSymbols.update(newlyNullableSymbols)
        newlyNullableSymbols = grammar.findMoreNullableSymbols(nullableSymbols)
        self.assertEqual(len(newlyNullableSymbols), 0)

if __name__ == '__main__':
    unittest.main()
