#!/usr/bin/env python3

import sys

import io
import copy

    
      
class Symbol:
    symbols = {}

    def __init__(self, value):
        self.value = value

    def __str__(self):
        if (self.isEpsilon()):
            return "ε"
        else:
            return self.value.__str__()
            
    def __repr__(self):
        if (self.isEpsilon()):
            return "ε"
        else:
            return self.value.__str__()

    @staticmethod
    def get(key):
        if key in Symbol.symbols:
            return Symbol.symbols[key]
        else:
            value = Symbol(key)
            Symbol.symbols[key] = value
            return value

    def isEpsilon(self):
        if (self.value == None):
            return True
        else:
            return False

    def isNonterminal(self):
        if self.isEpsilon():
            return False
        else:
            if self.value[0].isupper():
                return True
            else:
                return False

    def isTerminal(self):
        
        if self.isEpsilon:
            return False
        else:
            return not self.isNonterminal()


class Rule:
    def __init__(self, lhs, rhs):
        if (not lhs.isNonterminal()):
            raise RuntimeError(
                "The left-hand side of a context-free rule must be a nonterminal, but " + lhs.__str__() + " is not")
        self.lhs = lhs
        self.rhs = rhs

    def __str__(self):
        rhsStrings = [rhs.__str__() for rhs in self.rhs]
        return self.lhs.__str__() + " → " + " ".join(rhsStrings)
        
    def __repr__(self):
        rhsStrings = [rhs.__str__() for rhs in self.rhs]
        return self.lhs.__str__() + " → " + " ".join(rhsStrings)
        
    def isUnary(self):
      if len(self.rhs) == 1:
        return True
      else:
        return False

    @staticmethod
    def readLine(line):

        parts = line.split()
        lhs = Symbol.get(parts[0])

        if len(parts) > 1:
            rhs = [Symbol.get(rhsString) for rhsString in parts[1:]]
            return Rule(lhs, rhs)

        else:
            rhs = [Symbol.get(None)]
            return Rule(lhs, rhs)


class Grammar:
    def __init__(self, rules, counter=None):
        self.rules = rules
        if counter == None:
          self.counter = 0
        else:
          self.counter = counter
        
    def __str__(self):
      return str(self.rules)
    
      
    @staticmethod
    def readLines(file):

        rules = []
        for line in file:
            rule = Rule.readLine(line)
            rules.append(rule)

        return Grammar(rules)
    
    @staticmethod
    def delete_repeat(rules):
      newlist = []
      for i in rules:
        if i not in newlist:
          newlist.append(i)
      return newlist

    def findInitiallyNullableSymbols(self):
        # Returns the set of symbols that appear on the left-hand side of
        # unary-branching rules where the right-hand side is epsilon
        ret = []
        v = True
        for rule in self.rules:
            for symbols in rule.rhs:
                if not symbols.isEpsilon():
                    v = False
            if v == True:
                ret.append(rule.lhs)
            else:
                v = True

        return ret

    def findMoreNullableSymbols(self, nullableSymbols):
        """Given a set of nullable symbols, returns a new set of nullable symbols.

           The returned set will consist of symbols that appear on the left-hand side of rules
           in which all symbols on the right-hand side are in the initial set of nullable symbols"""
        ret = []
        v = True
        for rule in self.rules:
            for symbol in rule.rhs:
                if symbol not in nullableSymbols:
                    v = False
            if v == True and rule.lhs not in nullableSymbols and rule.lhs not in ret:
                ret.append(rule.lhs)
            else:
                v = True

        return ret

    def findNullableSymbols(self):
        """Returns all nullable symbols in this grammar"""
        # Step 1: findInitiallyNullableSymbols
        nullable = self.findInitiallyNullableSymbols()

        # Step 2: use the results from step 1 to call findMoreNullableSymbols
        temp = self.findMoreNullableSymbols(nullable)


        while len(temp) > 0:
            # Step 3: add the newly nullable symbols to the set of nullable symbols
            nullable = nullable + temp

            # Step 4: use the results from step 3 to call findMoreNullableSymbols
            temp = self.findMoreNullableSymbols(nullable)

        # ... repeat steps 3 and 4 until the results of step 4 is the empty set

        # Return the set of nullable symbols
        return nullable

    def removeEpsilons(self):
        """Returns an equivalent grammar that contains no epsilons"""
        new_rules = []
        nonterminal = []
        
        #remove rule that "ε" on rhs and add its left hand side to nonterminal
        for rule in self.rules:
          for symbol in rule.rhs:
            if not symbol.isEpsilon():
              new_rules.append(rule)
              continue
            else:
              nonterminal.append(rule.lhs)
        
        while(len(nonterminal)>0):
        
          for rule in new_rules:
            if rule.lhs in nonterminal:
               nonterminal.remove(rule.lhs)
            
          for rule in new_rules:
            for symbol in rule.rhs:
              if symbol in nonterminal:
                symbol.value = None
          
          nonterminal = []
          
          for rule in new_rules:
            for symbol in rule.rhs:
              if not symbol.isEpsilon():
                continue
              else:
                nonterminal.append(rule.lhs)
                new_rules.remove(rule)
              
            
        return Grammar(Grammar.delete_repeat(new_rules))        
        



    def removeUnaryRules(self):
      """Returns an equivalent grammar that contains no unary-branching rules in which the right-hand side is a non-terminal"""
        
      # Eg: NP -> N
      #     N -> dog
      new_rules = copy.deepcopy(self.rules)
        
      def has_unary(rules):
        for rule in rules:
          if rule.isUnary() and rule.rhs[0].isNonterminal():
             return True
          return False
      
      while(has_unary(new_rules)):
          # seperate NP -> N from others
          for rule in new_rules:
            if rule.isUnary() and rule.rhs[0].isNonterminal():
              new_rules.remove(rule)
              
              #find and add
              for rule1 in new_rules:
                if rule1.lhs == rule.rhs[0]:
                  new_rules.append(Rule(rule.lhs, rule1.rhs))
      
      
            
      return Grammar(Grammar.delete_repeat(new_rules))


    def shortenLongRules(self):
        """Returns an equivalent grammar in which the right-hand side of every rule contains no more than two symbols"""
        
        counter =self.counter
        new_rules =[]
        
        # S -> ABCDE
        for rule in self.rules:
          if len(rule.rhs) > 2:
            
            for i in range(len(rule.rhs)-1):
              new_symbol = Symbol.get('T'+str(counter))
              rhs = [rule.rhs[i],new_symbol]
              if i == 0: # S -> A T0
                new_rules.append(Rule(rule.lhs, rhs))
              elif i == len(rule.rhs)-2: # T2 -> D E
                new_rules.append(Rule(Symbol.get('T'+str(counter-1)), rule.rhs[-2:]))
              else: # T0 -> B T1, T1 -> C T2 
                new_rules.append(Rule(Symbol.get('T'+str(counter-1)), rhs))
              counter += 1
          else:
            new_rules.append(rule)
            
          
        return Grammar(Grammar.delete_repeat(new_rules), counter)

    def makeTerminalsUnary(self):
        """Returns an equivalent grammar where every terminal is found only as the right-hand side of a unary-branching rule"""
        new_rules =[]
        counter = self.counter
        
        for rule in self.rules:
          if len(rule.rhs) > 1:
            rhs = []
            for symbol in rule.rhs:
              #if symbol.isTerminal is not working?
              if not symbol.value[0].isupper(): 
                new_symbol = Symbol.get('T'+str(counter))
                rhs.append(new_symbol)
                new_rules.append(Rule(new_symbol, [symbol]))
                counter += 1
              else:
                rhs.append(symbol)
            new_rules.append(Rule(rule.lhs, rhs))
          else:
            new_rules.append(rule)
            
            
        return Grammar(Grammar.delete_repeat(new_rules), counter)

if __name__ == "__main__":

    if len(sys.argv) < 2:

        print("Please provide a file as argument")

    else:

        fileName = sys.argv[1]

        with open(fileName) as file:

            grammar = Grammar.readLines(file)

            for rule in grammar.rules:

                print(rule)
                
#         with open('lines.txt', 'r') as grammar_file:

#             grammar0 = Grammar.readLines(grammar_file)
#             print(grammar0)
#             grammar1 = grammar0.removeEpsilons()
#             print(grammar1)
#             grammar2 = grammar1.removeUnaryRules()
#             print(grammar2)
#             grammar3 = grammar2.shortenLongRules()
#             print(grammar3)
#             grammar4 = grammar0.makeTerminalsUnary()
#             print(grammar4)

            

            
